import { Component, OnInit } from '@angular/core';
import { UserloginService } from 'src/app/userlogin.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor(private user:UserloginService) { }

  ngOnInit() {
  }

}
