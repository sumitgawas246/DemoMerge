import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ChartsModule } from 'ng2-charts'
import { HttpClientModule } from '@angular/common/http';
import { NotificationComponent } from './notification/notification.component';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AreaComponent } from './area/area.component';
import { CustomerComponent } from './customer/customer.component';
import { UserloginService } from './userlogin.service';
import { AuthGuard } from './auth.guard';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { HomepageComponent } from './homepage/homepage.component';





const appRoutes: Routes = [
  { 
    path: '',
    component:LoginpageComponent
  },

  { 
    path: 'home',
    canActivate:[AuthGuard],
    component: HomeComponent,
  },

  { 
    path: 'homepage',
    canActivate:[AuthGuard],
    component: HomepageComponent,
  },

  { 
    path: 'notification',
    component: NotificationComponent 
  },

  { path: 'area', 
    component: AreaComponent 
  },

  { 
    path: 'customer', 
    component: CustomerComponent 
  },
];


@NgModule({
  declarations: [
    LoginpageComponent,
    NotificationComponent,
    HomeComponent,
    AreaComponent,
    CustomerComponent,
    LoginpageComponent,
    AppComponent,
    HomepageComponent

  ],
  imports: [
    RouterModule.forRoot(appRoutes)// <-- debugging purposes only
,
        
    BrowserModule,
    ChartsModule,
    HttpClientModule
  ],
  providers: [UserloginService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
