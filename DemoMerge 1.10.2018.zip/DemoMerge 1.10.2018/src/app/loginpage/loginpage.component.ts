import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserloginService } from 'src/app/userlogin.service';

import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {

  constructor(private router: Router, private user:UserloginService, private httpService:HttpClient) { }

  arrData: string[];
  arrData1: any;
  arrData2: any;
  ngOnInit() {
  }

  loginUser(e){
    e.preventDefault();
    var username = e.target.elements[0].value;
    var password = e.target.elements[1].value;
    // console.log(username, password);
    // return false;
    
    this.httpService.get('./assets/dataFiles/loginData.json').subscribe(
      data =>{  
        this.arrData = data as string[];
        this.arrData1 = JSON.stringify(data)
        console.log(this.arrData1);
        console.log(data);
        console.log(this.arrData[0]); 
        console.log(password);
        console.log(data[0].user);
        console.log(data[0].pass);
        // if(username == data[1].user && password == data[1].pass){

        // this.arrData.forEach(element => {
        //   console.log(element);
        //   this.arrData2 = JSON.stringify(element)
        //   console.log(this.arrData2);
          if(username == data[0].user && password == data[0].pass){
            
            this.user.setUserLoggedIn();
            this.router.navigate(['home'])
          }

          
               
          else {
            alert("Username and Password not matched.");
          } 
      //   } 
        
      // );
        
      },
      (err:HttpErrorResponse) =>{
        console.log(err.message);
      }

    );
      // console.log(this.arrData);
    




    /* ------------------------------------  This is old code without json file   --------------------------------------- */
    // if(username == 'Sumit' && password == 'Sumit@123'){
    // this.user.setUserLoggedIn();
    // this.router.navigate(['homepage'])
    // }
    // else{
    //   alert("Username and Password not matched.");
    // }
    /* ------------------------------------------------------------------------------------------------------------------- */
  }
}
